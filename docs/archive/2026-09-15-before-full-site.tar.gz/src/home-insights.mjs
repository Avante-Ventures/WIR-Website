// Homepage metadata snapshot from src/articles.jsx, 2026-09-14. Full article bodies remain lazy.
export const HOME_INSIGHTS = {
  "pt": [
    {
      "slug": "defesa-civil-do-estado-de-sao-paulo",
      "title": "Defesa Civil do Estado de São Paulo: o que é, como funciona e como receber os alertas",
      "date": "09 · Set · 2026",
      "dateISO": "2026-09-09",
      "image": "/assets/articles/defesa-civil-do-estado-de-sao-paulo.jpg",
      "time": "7 min"
    },
    {
      "slug": "nicholas-weiser-entrevista",
      "title": "Nicholas Weiser: 27 anos de mercado até fundar a WIR",
      "date": "04 · Set · 2026",
      "dateISO": "2026-09-04",
      "image": "/assets/articles/nicholas-weiser-entrevista.jpg",
      "time": "12 min"
    },
    {
      "slug": "jose-carlos-de-paula-entrevista",
      "title": "José Carlos de Paula: quatro décadas entre banco, seguro e saúde",
      "date": "04 · Set · 2026",
      "dateISO": "2026-09-04",
      "image": "/assets/articles/jose-carlos-de-paula-entrevista.jpg",
      "time": "12 min"
    }
  ],
  "en": [
    {
      "slug": "sao-paulo-state-civil-defense",
      "title": "São Paulo State Civil Defense: What It Is, What It Does, and Why P&C Insurers Should Care",
      "date": "09 · Sep · 2026",
      "dateISO": "2026-09-09",
      "image": "/assets/articles/sao-paulo-state-civil-defense.jpg",
      "time": "8 min"
    },
    {
      "slug": "nicholas-weiser-entrevista-en",
      "title": "Nicholas Weiser: 27 years in the market before founding WIR",
      "date": "04 · Sep · 2026",
      "dateISO": "2026-09-04",
      "image": "/assets/articles/nicholas-weiser-entrevista-en.jpg",
      "time": "12 min"
    },
    {
      "slug": "jose-carlos-de-paula-entrevista-en",
      "title": "José Carlos de Paula: four decades across banking, insurance and healthcare",
      "date": "04 · Sep · 2026",
      "dateISO": "2026-09-04",
      "image": "/assets/articles/jose-carlos-de-paula-entrevista-en.jpg",
      "time": "12 min"
    }
  ]
};
